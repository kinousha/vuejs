const products = [
  { id: 1, description: "carotte", price: 12, img: 'assets/img/carotte.jpeg'},
  { id: 2, description: 'Cereale', price: 20, img: 'assets/img/cereale.jpg'},
  { id: 3, description: 'Choux', price: 5, img: 'assets/img/choux.jpeg'},
  { id: 4, description: 'Lait', price: 8, img: 'assets/img/lait.jpg'},
  { id: 5, description: 'oeuf', price: 3, img: 'assets/img/oeuf.jpeg'},
  { id: 6, description: 'Riz', price: 65, img: 'assets/img/riz.jpg'},
  { id: 7, description: 'Pomme de terre', price: 25, img: 'assets/img/patate.jpg'},
  { id: 8, description: 'Carotte', price: 28, img: 'assets/img/carotte.jpeg'},
  { id: 9, description: 'oeuf', price: 4, img: 'assets/img/oeuf.jpeg'},
  { id: 10, description: 'cereale', price: 29, img: 'assets/img/cereale.jpg'},
  { id: 11, description: 'choux', price: 87, img: 'assets/img/choux.jpeg'},
  { id: 12, description: 'choux', price: 6, img: 'assets/img/patate.jpg'},
  { id: 13, description: 'Pomme de terre', price: 25, img: 'assets/img/patate.jpg'},
  { id: 14, description: 'Pomme de terre', price: 28, img: 'assets/img/carotte.jpeg'},
  { id: 15, description: 'carotte', price: 4, img: 'assets/img/oeuf.jpeg'},

];

const Home = {
  template:'#home',
  name:'Home',
  data: () =>{
    return {
      products,
      searchKey:'',
      liked: [],
      cart: []
    }
  },
  computed: {
     filteredList(){
       return this.products.filter((product) =>{
         return product.description.toLowerCase().includes(this.searchKey.toLowerCase());
       })
     },
     cartTotalAmount(){
       let total=0;
       for (let item in this.cart) {
         total =total + (this.cart[item].quantity * this.cart[item].price)
       }
       return total;
     },
     itemTotalAmount(){
       let itemTotal = 0;
       for (let item in this.cart) {
         itemTotal=itemTotal + (this.cart[item].quantity);

       }
       return itemTotal;
     }
  },
  methods: {
    setLikeCookie(){

    },
    addToCart(product){
      for (let i = 0; i < this.cart.length; i++) {
       if (this.cart[i].id===product.id) {
         return this.cart[i].quantity++
       }
      }
      this.cart.push({
          id:product.id,
          img:product.img,
          description:product.description,
          price:product.price,
          quantity:1
        })
    },
    cartPlusOne(product){
      product.quantity=product.quantity + 1;
    },
    cartMinusOne(product, id){
      if (product.quantity== 1) {
        this.cartRemoveItem(id);
      }else {
        product.quantity=product.quantity -1;
      }
    },
    cartRemoveItem(id){
      this.$delete(this.cart,id)
    }
  }

}
const UserSettings = {
  template:'#UserSettings',

  name:'UserSettings'
}

const WishList = {
  template:'<h1>WishList</h1>',
  name:'WishList'
}
const ShoppingCart ={

  template:'<h1>ShoppingCart </h1>',
  name:'ShoppingCart'
}
const Connecter = {
  template:'#Connecte',

  name:'Connecter'
}

const router =new VueRouter(
  {
    routes:[
      {path:'/',component: Home,name:'Home'},
      {path:'/user-settings',component:UserSettings,name:'UserSettings'},
      {path:'/wish-list',component:WishList,name:'WishList'},
      {path:'/shopping-cart',component:ShoppingCart,name:'ShoppingCart'},
      {path:'/login',component:Connecter,name:'Connecter'}


    ]
  })
const vue =new Vue(
  {
    router
  }
).$mount('#app');
